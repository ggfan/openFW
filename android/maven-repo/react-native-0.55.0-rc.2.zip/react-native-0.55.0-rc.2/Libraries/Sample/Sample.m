#import "Sample.h"

@implementation Sample

RCT_EXPORT_MODULE()

RCT_EXPORT_METHOD(test)
{
  // Your implementation here
}

@end
